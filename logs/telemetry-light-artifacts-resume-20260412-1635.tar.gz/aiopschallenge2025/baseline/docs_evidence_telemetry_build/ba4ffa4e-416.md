# Telemetry Evidence Case

- case_id: ba4ffa4e-416
- time_window_utc: 2025-06-21T01:10:10Z -> 2025-06-21T01:28:10Z
- instance_type: pod
- service: tidb-tikv
- instance: tidb-tikv-0, tidb-tikv

## Anomaly Description

Please analyze the abnormal event between 2025-06-21T01:10:10Z and 2025-06-21T01:28:10Z and provide the root cause.

## Metric Signals

- no metric signal extracted

## Log Signals

- no log signal extracted

## Trace Signals

- no trace signal extracted

## Retrieval Keywords

tidb-tikv tidb-tikv-0
