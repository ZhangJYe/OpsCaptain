# Telemetry Evidence Case

- case_id: b1affa2a-424
- time_window_utc: 2025-06-21T09:10:19Z -> 2025-06-21T09:21:19Z
- instance_type: node
- service: unknown
- instance: aiops-k8s-08

## Anomaly Description

Determine the root cause of the system fault during 2025-06-21T09:10:19Z to 2025-06-21T09:21:19Z.

## Metric Signals

- node_memory_MemAvailable_bytes [aiops-k8s-08] from infra_node_node_memory_MemAvailable_bytes_2025-06-21.parquet: baseline_mean=7915874030.93, incident_mean=10800512279.27, incident_max=11596115968.00, score=0.36, samples=11
- node_memory_usage_rate [aiops-k8s-08] from infra_node_node_memory_usage_rate_2025-06-21.parquet: baseline_mean=73.46, incident_mean=64.89, incident_max=66.55, score=0.12, samples=11
- node_disk_written_bytes_total [aiops-k8s-08] from infra_node_node_disk_written_bytes_total_2025-06-21.parquet: baseline_mean=173649.77, incident_mean=162564.66, incident_max=222276.27, score=0.06, samples=11
- node_cpu_usage_rate [aiops-k8s-08] from infra_node_node_cpu_usage_rate_2025-06-21.parquet: baseline_mean=34.38, incident_mean=33.31, incident_max=36.86, score=0.03, samples=11
- node_network_receive_bytes_total [aiops-k8s-08] from infra_node_node_network_receive_bytes_total_2025-06-21.parquet: baseline_mean=119.67, incident_mean=119.16, incident_max=121.20, score=0.00, samples=11
- node_network_transmit_bytes_total [aiops-k8s-08] from infra_node_node_network_transmit_bytes_total_2025-06-21.parquet: baseline_mean=3642.35, incident_mean=3639.98, incident_max=3644.87, score=0.00, samples=11
- node_filesystem_free_bytes [aiops-k8s-08] from infra_node_node_filesystem_free_bytes_2025-06-21.parquet: baseline_mean=9181907080.53, incident_mean=9183656122.18, incident_max=9192525824.00, score=0.00, samples=11

## Log Signals

- currencyservice-2 @ aiops-k8s-08: count=9497, window=2025-06-21T09:10:20.051Z -> 2025-06-21T09:21:19.374Z, pattern=json message=conversion request successful severity=info
- currencyservice-2 @ aiops-k8s-08: count=9497, window=2025-06-21T09:10:20.050Z -> 2025-06-21T09:21:19.372Z, pattern=json message=received conversion request severity=info
- cartservice-2 @ aiops-k8s-08: count=3910, window=2025-06-21T09:10:20.047Z -> 2025-06-21T09:21:19.815Z, pattern=GetCartAsync called with userId=<uuid>
- currencyservice-2 @ aiops-k8s-08: count=2736, window=2025-06-21T09:10:20.045Z -> 2025-06-21T09:21:19.364Z, pattern=json message=Getting supported currencies... severity=info
- frontend-2 @ aiops-k8s-08: count=1683, window=2025-06-21T09:10:20.115Z -> 2025-06-21T09:21:19.321Z, pattern=json message=request complete severity=debug http.resp.status=<n>
- frontend-2 @ aiops-k8s-08: count=1683, window=2025-06-21T09:10:20.030Z -> 2025-06-21T09:21:19.232Z, pattern=json message=request started severity=debug

## Trace Signals

- no trace signal extracted

## Retrieval Keywords

aiops-k8s-08 node_memory_MemAvailable_bytes node_memory_usage_rate node_disk_written_bytes_total node_cpu_usage_rate node_network_receive_bytes_total
