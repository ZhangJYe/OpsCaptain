# Telemetry Evidence Case

- case_id: c0cdda5e-314
- time_window_utc: 2025-06-16T19:10:06Z -> 2025-06-16T19:20:06Z
- instance_type: node
- service: unknown
- instance: aiops-k8s-05

## Anomaly Description

The system experienced an anomaly from 2025-06-16T19:10:06Z to 2025-06-16T19:20:06Z. Please infer the possible cause.

## Metric Signals

- node_filesystem_usage_rate [aiops-k8s-05] from infra_node_node_filesystem_usage_rate_2025-06-17.parquet: baseline_mean=25.16, incident_mean=65.59, incident_max=95.46, score=1.61, samples=20
- node_memory_usage_rate [aiops-k8s-05] from infra_node_node_memory_usage_rate_2025-06-17.parquet: baseline_mean=37.89, incident_mean=40.62, incident_max=41.16, score=0.07, samples=10
- node_disk_written_bytes_total [aiops-k8s-05] from infra_node_node_disk_written_bytes_total_2025-06-17.parquet: baseline_mean=130125.93, incident_mean=138990.93, incident_max=196881.07, score=0.07, samples=10
- node_memory_MemAvailable_bytes [aiops-k8s-05] from infra_node_node_memory_MemAvailable_bytes_2025-06-17.parquet: baseline_mean=10079223398.40, incident_mean=9621437235.20, incident_max=9721880576.00, score=0.05, samples=10
- node_network_transmit_bytes_total [aiops-k8s-05] from infra_node_node_network_transmit_bytes_total_2025-06-17.parquet: baseline_mean=5234.87, incident_mean=5232.80, incident_max=5235.13, score=0.00, samples=10
- node_filesystem_free_bytes [aiops-k8s-05] from infra_node_node_filesystem_free_bytes_2025-06-17.parquet: baseline_mean=16601384277.33, incident_mean=16603407564.80, incident_max=16613179392.00, score=0.00, samples=10

## Log Signals

- currencyservice-0 @ aiops-k8s-05: count=1130, window=2025-06-16T19:10:08.245Z -> 2025-06-16T19:20:03.242Z, pattern=json message=conversion request successful severity=info
- currencyservice-0 @ aiops-k8s-05: count=1130, window=2025-06-16T19:10:08.244Z -> 2025-06-16T19:20:03.241Z, pattern=json message=received conversion request severity=info
- currencyservice-0 @ aiops-k8s-05: count=326, window=2025-06-16T19:10:08.238Z -> 2025-06-16T19:20:03.237Z, pattern=json message=Getting supported currencies... severity=info
- cartservice-1 @ aiops-k8s-05: count=17, window=2025-06-16T19:11:20.997Z -> 2025-06-16T19:20:01.912Z, pattern=EmptyCartAsync called with userId=<uuid>
- cartservice-1 @ aiops-k8s-05: count=17, window=2025-06-16T19:11:10.591Z -> 2025-06-16T19:19:55.788Z, pattern=GetCartAsync called with userId=<uuid>
- paymentservice-1 @ aiops-k8s-05: count=8, window=2025-06-16T19:12:33.173Z -> 2025-06-16T19:18:26.847Z, pattern=json message=PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"<n>","nanos":<n>},"credit_card":{"credit_card_number":"<n>-<n>-<n>-<n>","credit_card_cvv":<n>,"credit_card_expiration_year

## Trace Signals

- no trace signal extracted

## Retrieval Keywords

aiops-k8s-05 node_filesystem_usage_rate node_memory_usage_rate node_disk_written_bytes_total node_memory_MemAvailable_bytes node_network_transmit_bytes_total
