# Telemetry Evidence Case

- case_id: aba2da7f-368
- time_window_utc: 2025-06-19T01:10:09Z -> 2025-06-19T01:32:09Z
- instance_type: service
- service: unknown
- instance: frontend, cartservice
- path: frontend -> cartservice

## Anomaly Description

A fault was detected from 2025-06-19T01:10:09Z to 2025-06-19T01:32:09Z. Please analyze its root cause.

## Metric Signals

- rrt [cartservice-1] from pod_cartservice-1_2025-06-19.parquet: baseline_mean=7832.17, incident_mean=243841.06, incident_max=280169.51, score=30.13, samples=22
- rrt [cartservice-0] from pod_cartservice-0_2025-06-19.parquet: baseline_mean=6388.49, incident_mean=196879.52, incident_max=224163.33, score=29.82, samples=22
- rrt [cartservice] from service_cartservice_2025-06-19.parquet: baseline_mean=7719.10, incident_mean=233098.75, incident_max=267080.63, score=29.20, samples=22
- rrt [cartservice-2] from pod_cartservice-2_2025-06-19.parquet: baseline_mean=8520.48, incident_mean=244187.20, incident_max=281041.88, score=27.66, samples=22
- rrt_max [cartservice-0] from pod_cartservice-0_2025-06-19.parquet: baseline_mean=65170.13, incident_mean=1602973.00, incident_max=1829876.00, score=23.60, samples=22
- rrt_max [cartservice-1] from pod_cartservice-1_2025-06-19.parquet: baseline_mean=68256.70, incident_mean=1646347.36, incident_max=2606857.00, score=23.12, samples=22
- rrt_max [cartservice-2] from pod_cartservice-2_2025-06-19.parquet: baseline_mean=69437.93, incident_mean=1663949.09, incident_max=2943645.00, score=22.96, samples=22
- rrt_max [cartservice] from service_cartservice_2025-06-19.parquet: baseline_mean=73703.43, incident_mean=1671437.50, incident_max=2943645.00, score=21.68, samples=22

## Log Signals

- frontend-2 @ aiops-k8s-08: count=961, window=2025-06-19T01:10:10.735Z -> 2025-06-19T01:32:06.762Z, pattern=json message=request complete severity=debug http.resp.status=<n>
- frontend-2 @ aiops-k8s-08: count=961, window=2025-06-19T01:10:10.649Z -> 2025-06-19T01:32:09.010Z, pattern=json message=request started severity=debug
- frontend-0 @ aiops-k8s-04: count=950, window=2025-06-19T01:10:10.464Z -> 2025-06-19T01:32:09.832Z, pattern=json message=request started severity=debug
- frontend-0 @ aiops-k8s-04: count=949, window=2025-06-19T01:10:10.549Z -> 2025-06-19T01:32:09.719Z, pattern=json message=request complete severity=debug http.resp.status=<n>
- cartservice-1 @ aiops-k8s-05: count=805, window=2025-06-19T01:10:10.482Z -> 2025-06-19T01:32:09.850Z, pattern=GetCartAsync called with userId=<uuid>
- cartservice-2 @ aiops-k8s-08: count=799, window=2025-06-19T01:10:10.666Z -> 2025-06-19T01:32:09.027Z, pattern=GetCartAsync called with userId=<uuid>

## Trace Signals

- frontend | hipstershop.CartService/GetCart: peer=hipstershop.CartService, count=1903, errors=0, avg_ms=1464.35, p95_ms=1595.01
- frontend | hipstershop.Frontend/Recv.: peer=10.233.89.75, count=2197, errors=0, avg_ms=1365.13, p95_ms=1683.83
- frontend | hipstershop.CartService/AddItem: peer=hipstershop.CartService, count=188, errors=0, avg_ms=1456.87, p95_ms=1588.53
- frontend | hipstershop.Frontend/Recv.: peer=10.233.89.198, count=185, errors=0, avg_ms=1361.26, p95_ms=1679.79
- frontend | hipstershop.CheckoutService/PlaceOrder: peer=hipstershop.CheckoutService, count=96, errors=0, avg_ms=149.86, p95_ms=219.33
- frontend | hipstershop.ProductCatalogService/GetProduct: peer=hipstershop.ProductCatalogService, count=10688, errors=0, avg_ms=11.54, p95_ms=18.70

## Retrieval Keywords

frontend cartservice rrt rrt_max hipstershop.CartService/GetCart hipstershop.Frontend/Recv.
