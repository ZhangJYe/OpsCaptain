# Telemetry Evidence Case

- case_id: d0ecec7e-381
- time_window_utc: 2025-06-19T14:10:30Z -> 2025-06-19T14:21:30Z
- instance_type: service
- service: checkoutservice
- instance: checkoutservice

## Anomaly Description

The system experienced an anomaly from 2025-06-19T14:10:30Z to 2025-06-19T14:21:30Z. Please infer the possible cause.

## Metric Signals

- server_error_ratio [hipstershop] from pod_ns_hipstershop_2025-06-19.parquet: baseline_mean=0.00, incident_mean=0.11, incident_max=0.14, score=159.82, samples=11
- server_error [hipstershop] from pod_ns_hipstershop_2025-06-19.parquet: baseline_mean=0.07, incident_mean=10.36, incident_max=14.00, score=149.27, samples=11
- client_error [checkoutservice] from service_checkoutservice_2025-06-19.parquet: baseline_mean=5.79, incident_mean=0.00, incident_max=0.00, score=1.00, samples=5
- client_error_ratio [checkoutservice] from service_checkoutservice_2025-06-19.parquet: baseline_mean=1.19, incident_mean=0.00, incident_max=0.00, score=1.00, samples=5
- client_error [checkoutservice-1] from pod_checkoutservice-1_2025-06-19.parquet: baseline_mean=9.10, incident_mean=0.00, incident_max=0.00, score=1.00, samples=5
- client_error_ratio [checkoutservice-1] from pod_checkoutservice-1_2025-06-19.parquet: baseline_mean=11.01, incident_mean=0.00, incident_max=0.00, score=1.00, samples=5
- client_error [checkoutservice-2] from pod_checkoutservice-2_2025-06-19.parquet: baseline_mean=1.24, incident_mean=0.00, incident_max=0.00, score=1.00, samples=5
- client_error_ratio [checkoutservice-2] from pod_checkoutservice-2_2025-06-19.parquet: baseline_mean=0.53, incident_mean=0.00, incident_max=0.00, score=1.00, samples=5

## Log Signals

- no log signal extracted

## Trace Signals

- frontend | hipstershop.CheckoutService/PlaceOrder: peer=hipstershop.CheckoutService, count=56, errors=56, avg_ms=0.22, p95_ms=0.38

## Retrieval Keywords

checkoutservice server_error_ratio server_error client_error client_error_ratio frontend hipstershop.CheckoutService/PlaceOrder
