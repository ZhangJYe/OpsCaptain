# Telemetry Evidence Case

- case_id: 0fccdcad-125
- time_window_utc: 2025-06-07T15:11:05Z -> 2025-06-07T15:33:05Z
- instance_type: service
- service: recommendationservice
- instance: recommendationservice

## Anomaly Description

A fault occurred from 2025-06-07T15:11:05Z to 2025-06-07T15:33:05Z. Please identify the root cause.

## Metric Signals

- pod_cpu_usage [recommendationservice-2,recommendationservice-1,recommendationservice-0] from infra_pod_pod_cpu_usage_2025-06-07.parquet: baseline_mean=0.00, incident_mean=0.40, incident_max=0.40, score=399.00, samples=66
- rrt_max [recommendationservice-2] from pod_recommendationservice-2_2025-06-07.parquet: baseline_mean=21108.10, incident_mean=329695.73, incident_max=586976.00, score=14.62, samples=22
- rrt [recommendationservice-2] from pod_recommendationservice-2_2025-06-07.parquet: baseline_mean=4357.29, incident_mean=56926.84, incident_max=69953.24, score=12.06, samples=22
- rrt_max [recommendationservice] from service_recommendationservice_2025-06-07.parquet: baseline_mean=26353.17, incident_mean=324568.05, incident_max=586976.00, score=11.32, samples=22
- rrt [recommendationservice] from service_recommendationservice_2025-06-07.parquet: baseline_mean=4104.76, incident_mean=47896.37, incident_max=59994.04, score=10.67, samples=22
- rrt [recommendationservice-0] from pod_recommendationservice-0_2025-06-07.parquet: baseline_mean=3582.23, incident_mean=40872.85, incident_max=48841.97, score=10.41, samples=22
- rrt_max [recommendationservice-0] from pod_recommendationservice-0_2025-06-07.parquet: baseline_mean=24923.03, incident_mean=249772.91, incident_max=363435.00, score=9.02, samples=22
- pod_processes [recommendationservice-2,recommendationservice-1,recommendationservice-0] from infra_pod_pod_processes_2025-06-07.parquet: baseline_mean=1.00, incident_mean=9.00, incident_max=9.00, score=8.00, samples=66

## Log Signals

- recommendationservice-2 @ aiops-k8s-01: count=2, window=2025-06-07T15:12:52.431Z -> 2025-06-07T15:25:33.135Z, pattern=json message=[Recv ListRecommendations] product_ids=['0PUK6V6EV0', '66VCHSJNUP', 'OLJCESPC7Z', '7JSJCESPC9H', 'COFFEE789'] severity=INFO
- recommendationservice-2 @ aiops-k8s-01: count=2, window=2025-06-07T15:23:42.738Z -> 2025-06-07T15:32:55.735Z, pattern=json message=[Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '9SIQT8TOJO', 'COFFEE789', 'L9ECAV7KIM', 'PHOTO202'] severity=INFO
- recommendationservice-2 @ aiops-k8s-01: count=2, window=2025-06-07T15:25:24.932Z -> 2025-06-07T15:26:24.140Z, pattern=json message=[Recv ListRecommendations] product_ids=['66VCHSJNUP', '7JSJCESPC9H', 'COFFEE789', 'LS4PSXUNUM', 'L9ECAV7KIM'] severity=INFO
- recommendationservice-0 @ aiops-k8s-08: count=2, window=2025-06-07T15:19:50.868Z -> 2025-06-07T15:30:23.664Z, pattern=json message=[Recv ListRecommendations] product_ids=['9SIQT8TOJO', '1YMWWN1N4O', '7JSJCESPC9H', 'VINTAGE123', 'COFFEE789'] severity=INFO
- recommendationservice-2 @ aiops-k8s-01: count=2, window=2025-06-07T15:21:18.731Z -> 2025-06-07T15:27:28.732Z, pattern=json message=[Recv ListRecommendations] product_ids=['GARDEN101', '7JSJCESPC9H', '2ZYFJ3GM2N', 'LS4PSXUNUM', '1YMWWN1N4O'] severity=INFO
- recommendationservice-0 @ aiops-k8s-08: count=2, window=2025-06-07T15:26:58.369Z -> 2025-06-07T15:32:42.662Z, pattern=json message=[Recv ListRecommendations] product_ids=['GARDEN101', 'PHOTO456', 'PHOTO202', 'VINTAGE123', 'COFFEE789'] severity=INFO

## Trace Signals

- frontend | hipstershop.RecommendationService/ListRecommendations: peer=hipstershop.RecommendationService, count=1971, errors=0, avg_ms=120.73, p95_ms=213.46
- recommendationservice | /hipstershop.RecommendationService/ListRecommendations: peer=unknown, count=1966, errors=0, avg_ms=64.35, p95_ms=188.31
- recommendationservice | /hipstershop.ProductCatalogService/ListProducts: peer=unknown, count=1966, errors=0, avg_ms=42.63, p95_ms=100.53

## Retrieval Keywords

recommendationservice pod_cpu_usage rrt_max rrt frontend hipstershop.RecommendationService/ListRecommendations /hipstershop.RecommendationService/ListRecommendations
