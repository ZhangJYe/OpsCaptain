# Telemetry Evidence Case

- case_id: bbfefe10-321
- time_window_utc: 2025-06-17T02:10:17Z -> 2025-06-17T02:33:17Z
- instance_type: node
- service: unknown
- instance: aiops-k8s-06

## Anomaly Description

Please analyze the abnormal event between 2025-06-17T02:10:17Z and 2025-06-17T02:33:17Z and provide the root cause.

## Metric Signals

- node_cpu_usage_rate [aiops-k8s-06] from infra_node_node_cpu_usage_rate_2025-06-17.parquet: baseline_mean=40.52, incident_mean=94.50, incident_max=96.05, score=1.33, samples=23
- node_disk_written_bytes_total [aiops-k8s-06] from infra_node_node_disk_written_bytes_total_2025-06-17.parquet: baseline_mean=124677.80, incident_mean=110025.09, incident_max=203161.60, score=0.12, samples=23
- node_memory_MemAvailable_bytes [aiops-k8s-06] from infra_node_node_memory_MemAvailable_bytes_2025-06-17.parquet: baseline_mean=26876959539.20, incident_mean=26822409527.65, incident_max=26852843520.00, score=0.00, samples=23
- node_filesystem_free_bytes [aiops-k8s-06] from infra_node_node_filesystem_free_bytes_2025-06-17.parquet: baseline_mean=8768693043.20, incident_mean=8774309442.78, incident_max=8783699968.00, score=0.00, samples=23
- node_network_transmit_bytes_total [aiops-k8s-06] from infra_node_node_network_transmit_bytes_total_2025-06-17.parquet: baseline_mean=3426.68, incident_mean=3425.42, incident_max=3429.73, score=0.00, samples=23

## Log Signals

- emailservice-2 @ aiops-k8s-06: count=93, window=2025-06-17T02:10:21.829Z -> 2025-06-17T02:33:13.730Z, pattern=json message=A request to send order confirmation email to someone@example.com has been received. severity=INFO
- checkoutservice-2 @ aiops-k8s-06: count=90, window=2025-06-17T02:10:21.829Z -> 2025-06-17T02:33:17.811Z, pattern=json message=order confirmation email sent to "someone@example.com" severity=info
- checkoutservice-2 @ aiops-k8s-06: count=90, window=2025-06-17T02:10:21.808Z -> 2025-06-17T02:33:17.797Z, pattern=json message=payment went through (transaction_id: <uuid>) severity=info
- checkoutservice-2 @ aiops-k8s-06: count=26, window=2025-06-17T02:10:21.754Z -> 2025-06-17T02:32:03.638Z, pattern=json message=[PlaceOrder] user_id="<uuid>" user_currency="USD" severity=info
- checkoutservice-2 @ aiops-k8s-06: count=25, window=2025-06-17T02:10:29.996Z -> 2025-06-17T02:33:17.713Z, pattern=json message=[PlaceOrder] user_id="<uuid>" user_currency="EUR" severity=info
- checkoutservice-2 @ aiops-k8s-06: count=21, window=2025-06-17T02:10:22.155Z -> 2025-06-17T02:33:17.255Z, pattern=json message=[PlaceOrder] user_id="<uuid>" user_currency="CAD" severity=info

## Trace Signals

- no trace signal extracted

## Retrieval Keywords

aiops-k8s-06 node_cpu_usage_rate node_disk_written_bytes_total node_memory_MemAvailable_bytes node_filesystem_free_bytes node_network_transmit_bytes_total
