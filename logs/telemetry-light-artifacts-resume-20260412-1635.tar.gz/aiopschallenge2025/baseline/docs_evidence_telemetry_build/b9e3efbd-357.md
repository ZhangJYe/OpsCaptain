# Telemetry Evidence Case

- case_id: b9e3efbd-357
- time_window_utc: 2025-06-18T14:10:27Z -> 2025-06-18T14:22:27Z
- instance_type: pod
- service: tidb-tikv
- instance: tidb-tikv-0, tidb-tikv

## Anomaly Description

Please analyze the abnormal event between 2025-06-18T14:10:27Z and 2025-06-18T14:22:27Z and provide the root cause.

## Metric Signals

- no metric signal extracted

## Log Signals

- no log signal extracted

## Trace Signals

- no trace signal extracted

## Retrieval Keywords

tidb-tikv tidb-tikv-0
