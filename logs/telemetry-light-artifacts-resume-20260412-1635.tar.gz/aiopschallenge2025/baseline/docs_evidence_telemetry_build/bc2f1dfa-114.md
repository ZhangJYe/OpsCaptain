# Telemetry Evidence Case

- case_id: bc2f1dfa-114
- time_window_utc: 2025-06-07T04:10:30Z -> 2025-06-07T04:26:30Z
- instance_type: node
- service: unknown
- instance: aiops-k8s-08

## Anomaly Description

The system experienced an anomaly from 2025-06-07T04:10:30Z to 2025-06-07T04:26:30Z. Please infer the possible cause.

## Metric Signals

- node_disk_read_bytes_total [aiops-k8s-08] from infra_node_node_disk_read_bytes_total_2025-06-07.parquet: baseline_mean=0.00, incident_mean=597.15, incident_max=9008.20, score=597.15, samples=16
- node_disk_write_time_seconds_total [aiops-k8s-08] from infra_node_node_disk_write_time_seconds_total_2025-06-07.parquet: baseline_mean=0.00, incident_mean=0.01, incident_max=0.04, score=0.50, samples=16
- node_disk_written_bytes_total [aiops-k8s-08] from infra_node_node_disk_written_bytes_total_2025-06-07.parquet: baseline_mean=763662.79, incident_mean=512496.90, incident_max=1774387.20, score=0.33, samples=16
- node_memory_MemAvailable_bytes [aiops-k8s-08] from infra_node_node_memory_MemAvailable_bytes_2025-06-07.parquet: baseline_mean=13376986180.27, incident_mean=10386531328.00, incident_max=12367048704.00, score=0.22, samples=16
- node_memory_usage_rate [aiops-k8s-08] from infra_node_node_memory_usage_rate_2025-06-07.parquet: baseline_mean=58.50, incident_mean=67.31, incident_max=79.89, score=0.15, samples=16
- node_network_transmit_bytes_total [aiops-k8s-08] from infra_node_node_network_transmit_bytes_total_2025-06-07.parquet: baseline_mean=3529.93, incident_mean=3528.97, incident_max=3535.33, score=0.00, samples=16
- node_filesystem_free_bytes [aiops-k8s-08] from infra_node_node_filesystem_free_bytes_2025-06-07.parquet: baseline_mean=9122050594.13, incident_mean=9123914240.00, incident_max=9136087040.00, score=0.00, samples=16

## Log Signals

- cartservice-2 @ aiops-k8s-08: count=87, window=2025-06-07T04:10:37.056Z -> 2025-06-07T04:26:30.674Z, pattern=EmptyCartAsync called with userId=<uuid>
- shippingservice-1 @ aiops-k8s-08: count=87, window=2025-06-07T04:10:36.971Z -> 2025-06-07T04:26:30.642Z, pattern=json message=[GetQuote] completed request severity=info
- shippingservice-1 @ aiops-k8s-08: count=87, window=2025-06-07T04:10:36.971Z -> 2025-06-07T04:26:30.642Z, pattern=json message=[GetQuote] received request severity=info
- cartservice-2 @ aiops-k8s-08: count=84, window=2025-06-07T04:10:44.912Z -> 2025-06-07T04:26:29.042Z, pattern=GetCartAsync called with userId=<uuid>
- shippingservice-1 @ aiops-k8s-08: count=84, window=2025-06-07T04:10:39.876Z -> 2025-06-07T04:26:26.332Z, pattern=json message=[ShipOrder] completed request severity=info
- shippingservice-1 @ aiops-k8s-08: count=84, window=2025-06-07T04:10:39.876Z -> 2025-06-07T04:26:26.332Z, pattern=json message=[ShipOrder] received request severity=info

## Trace Signals

- no trace signal extracted

## Retrieval Keywords

aiops-k8s-08 node_disk_read_bytes_total node_disk_write_time_seconds_total node_disk_written_bytes_total node_memory_MemAvailable_bytes node_memory_usage_rate
