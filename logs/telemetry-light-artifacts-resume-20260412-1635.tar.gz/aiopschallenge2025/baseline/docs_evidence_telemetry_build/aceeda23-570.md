# Telemetry Evidence Case

- case_id: aceeda23-570
- time_window_utc: 2025-06-27T11:10:35Z -> 2025-06-27T11:21:35Z
- instance_type: service
- service: unknown
- instance: checkoutservice, paymentservice
- path: checkoutservice -> paymentservice

## Anomaly Description

A fault occurred from 2025-06-27T11:10:35Z to 2025-06-27T11:21:35Z. Please identify the root cause.

## Metric Signals

- server_error [hipstershop] from pod_ns_hipstershop_2025-06-27.parquet: baseline_mean=0.03, incident_mean=18.09, incident_max=26.00, score=541.73, samples=11
- rrt_max [hipstershop] from pod_ns_hipstershop_2025-06-27.parquet: baseline_mean=240650.83, incident_mean=49560203.27, incident_max=60003360.00, score=204.94, samples=11
- rrt_max [checkoutservice] from service_checkoutservice_2025-06-27.parquet: baseline_mean=175924.57, incident_mean=33910076.91, incident_max=57743977.00, score=191.75, samples=11
- rrt_max [checkoutservice-0] from pod_checkoutservice-0_2025-06-27.parquet: baseline_mean=175924.57, incident_mean=33910076.91, incident_max=57743977.00, score=191.75, samples=11
- rrt [checkoutservice] from service_checkoutservice_2025-06-27.parquet: baseline_mean=4520.71, incident_mean=627108.07, incident_max=847395.65, score=137.72, samples=11
- rrt [checkoutservice-0] from pod_checkoutservice-0_2025-06-27.parquet: baseline_mean=4520.71, incident_mean=627108.07, incident_max=847395.65, score=137.72, samples=11
- rrt_max [paymentservice-2] from pod_paymentservice-2_2025-06-27.parquet: baseline_mean=2270.93, incident_mean=187686.91, incident_max=1623749.00, score=81.65, samples=11
- rrt_max [paymentservice] from service_paymentservice_2025-06-27.parquet: baseline_mean=3219.10, incident_mean=245885.09, incident_max=1623749.00, score=75.38, samples=11

## Log Signals

- checkoutservice-0 @ aiops-k8s-08: count=69, window=2025-06-27T11:11:06.503Z -> 2025-06-27T11:21:27.536Z, pattern=json message=order confirmation email sent to "someone@example.com" severity=info
- checkoutservice-0 @ aiops-k8s-08: count=69, window=2025-06-27T11:11:06.491Z -> 2025-06-27T11:21:27.525Z, pattern=json message=payment went through (transaction_id: <uuid>) severity=info
- checkoutservice-0 @ aiops-k8s-08: count=51, window=2025-06-27T11:11:09.175Z -> 2025-06-27T11:21:32.082Z, pattern=json message=[PlaceOrder] user_id="<uuid>" user_currency="CAD" severity=info
- checkoutservice-0 @ aiops-k8s-08: count=47, window=2025-06-27T11:10:47.793Z -> 2025-06-27T11:21:26.419Z, pattern=json message=[PlaceOrder] user_id="<uuid>" user_currency="JPY" severity=info
- checkoutservice-0 @ aiops-k8s-08: count=46, window=2025-06-27T11:10:49.911Z -> 2025-06-27T11:21:24.486Z, pattern=json message=[PlaceOrder] user_id="<uuid>" user_currency="EUR" severity=info
- checkoutservice-0 @ aiops-k8s-08: count=39, window=2025-06-27T11:10:40.305Z -> 2025-06-27T11:20:41.973Z, pattern=json message=[PlaceOrder] user_id="<uuid>" user_currency="USD" severity=info

## Trace Signals

- checkoutservice | hipstershop.CheckoutService/PlaceOrder: peer=hipstershop.CheckoutService, count=121, errors=74, avg_ms=22122.39, p95_ms=60000.44
- checkoutservice | hipstershop.PaymentService/Charge: peer=hipstershop.PaymentService, count=121, errors=73, avg_ms=22247.64, p95_ms=59961.67
- frontend | hipstershop.CheckoutService/PlaceOrder: peer=hipstershop.CheckoutService, count=116, errors=69, avg_ms=22218.85, p95_ms=60000.24
- checkoutservice | hipstershop.ProductCatalogService/GetProduct: peer=hipstershop.ProductCatalogService, count=244, errors=0, avg_ms=10.69, p95_ms=17.59
- checkoutservice | hipstershop.CurrencyService/Convert: peer=hipstershop.CurrencyService, count=374, errors=0, avg_ms=5.56, p95_ms=10.21
- checkoutservice | hipstershop.CartService/GetCart: peer=hipstershop.CartService, count=131, errors=0, avg_ms=6.08, p95_ms=11.00

## Retrieval Keywords

checkoutservice paymentservice server_error rrt_max rrt frontend hipstershop.CheckoutService/PlaceOrder hipstershop.PaymentService/Charge
