# Telemetry Evidence Case

- case_id: ac8cf6cb-553
- time_window_utc: 2025-06-26T18:10:05Z -> 2025-06-26T18:26:05Z
- instance_type: pod
- service: checkoutservice
- instance: checkoutservice-2

## Anomaly Description

The system experienced an anomaly from 2025-06-26T18:10:05Z to 2025-06-26T18:26:05Z. Please infer the possible cause.

## Metric Signals

- error_ratio [checkoutservice] from service_checkoutservice_2025-06-27.parquet: baseline_mean=1.38, incident_mean=64.49, incident_max=73.81, score=45.77, samples=16
- server_error_ratio [checkoutservice] from service_checkoutservice_2025-06-27.parquet: baseline_mean=1.38, incident_mean=64.49, incident_max=73.81, score=45.77, samples=16
- error_ratio [checkoutservice-2] from pod_checkoutservice-2_2025-06-27.parquet: baseline_mean=1.38, incident_mean=64.49, incident_max=73.81, score=45.77, samples=16
- server_error_ratio [checkoutservice-2] from pod_checkoutservice-2_2025-06-27.parquet: baseline_mean=1.38, incident_mean=64.49, incident_max=73.81, score=45.77, samples=16
- server_error_ratio [hipstershop] from pod_ns_hipstershop_2025-06-27.parquet: baseline_mean=0.05, incident_mean=1.39, incident_max=2.27, score=27.30, samples=16
- server_error [hipstershop] from pod_ns_hipstershop_2025-06-27.parquet: baseline_mean=4.50, incident_mean=122.50, incident_max=204.00, score=26.22, samples=16
- pod_cpu_usage [checkoutservice-2,checkoutservice-1,checkoutservice-0] from infra_pod_pod_cpu_usage_2025-06-27.parquet: baseline_mean=0.00, incident_mean=0.00, incident_max=0.00, score=1.00, samples=48
- pod_network_receive_bytes [checkoutservice-2,checkoutservice-1,checkoutservice-0] from infra_pod_pod_network_receive_bytes_2025-06-27.parquet: baseline_mean=427.79, incident_mean=55.63, incident_max=406.20, score=0.87, samples=48

## Log Signals

- checkoutservice-2 @ aiops-k8s-03: count=21, window=2025-06-26T18:10:10.850Z -> 2025-06-26T18:25:51.574Z, pattern=json message=[PlaceOrder] user_id="<uuid>" user_currency="CAD" severity=info
- checkoutservice-2 @ aiops-k8s-03: count=21, window=2025-06-26T18:10:32.865Z -> 2025-06-26T18:24:01.848Z, pattern=json message=[PlaceOrder] user_id="<uuid>" user_currency="EUR" severity=info
- checkoutservice-2 @ aiops-k8s-03: count=21, window=2025-06-26T18:10:13.540Z -> 2025-06-26T18:26:03.719Z, pattern=json message=[PlaceOrder] user_id="<uuid>" user_currency="JPY" severity=info
- checkoutservice-2 @ aiops-k8s-03: count=17, window=2025-06-26T18:11:22.077Z -> 2025-06-26T18:26:00.775Z, pattern=json message=[PlaceOrder] user_id="<uuid>" user_currency="USD" severity=info
- checkoutservice-2 @ aiops-k8s-03: count=1, window=2025-06-26T18:10:06.098Z -> 2025-06-26T18:10:06.098Z, pattern=json message=order confirmation email sent to "someone@example.com" severity=info
- checkoutservice-2 @ aiops-k8s-03: count=1, window=2025-06-26T18:10:06.073Z -> 2025-06-26T18:10:06.073Z, pattern=json message=payment went through (transaction_id: <uuid>) severity=info

## Trace Signals

- frontend | hipstershop.CheckoutService/PlaceOrder: peer=hipstershop.CheckoutService, count=81, errors=80, avg_ms=2896.12, p95_ms=8068.76
- checkoutservice | hipstershop.CheckoutService/PlaceOrder: peer=hipstershop.CheckoutService, count=81, errors=80, avg_ms=2894.07, p95_ms=8067.20
- checkoutservice | hipstershop.ProductCatalogService/GetProduct: peer=hipstershop.ProductCatalogService, count=82, errors=80, avg_ms=2582.05, p95_ms=5553.52
- checkoutservice | hipstershop.CartService/GetCart: peer=hipstershop.CartService, count=81, errors=0, avg_ms=277.31, p95_ms=2514.41
- checkoutservice | hipstershop.CurrencyService/Convert: peer=hipstershop.CurrencyService, count=3, errors=0, avg_ms=19.54, p95_ms=39.26
- checkoutservice | hipstershop.CartService/EmptyCart: peer=hipstershop.CartService, count=1, errors=0, avg_ms=8.58, p95_ms=8.58

## Retrieval Keywords

checkoutservice checkoutservice-2 error_ratio server_error_ratio frontend hipstershop.CheckoutService/PlaceOrder
