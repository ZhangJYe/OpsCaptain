# Telemetry Evidence Case

- case_id: bd4bafd7-567
- time_window_utc: 2025-06-27T08:10:30Z -> 2025-06-27T08:31:30Z
- instance_type: node
- service: unknown
- instance: aiops-k8s-08

## Anomaly Description

Please analyze the abnormal event between 2025-06-27T08:10:30Z and 2025-06-27T08:31:30Z and provide the root cause.

## Metric Signals

- node_disk_read_bytes_total [aiops-k8s-08] from infra_node_node_disk_read_bytes_total_2025-06-27.parquet: baseline_mean=0.00, incident_mean=219207.52, incident_max=3187780.27, score=219207.52, samples=21
- node_memory_MemAvailable_bytes [aiops-k8s-08] from infra_node_node_memory_MemAvailable_bytes_2025-06-27.parquet: baseline_mean=6300563865.60, incident_mean=9735607247.24, incident_max=11221585920.00, score=0.55, samples=21
- node_memory_usage_rate [aiops-k8s-08] from infra_node_node_memory_usage_rate_2025-06-27.parquet: baseline_mean=78.43, incident_mean=68.21, incident_max=80.57, score=0.13, samples=21
- node_disk_written_bytes_total [aiops-k8s-08] from infra_node_node_disk_written_bytes_total_2025-06-27.parquet: baseline_mean=140144.64, incident_mean=156036.47, incident_max=256955.73, score=0.11, samples=21
- node_filesystem_free_bytes [aiops-k8s-08] from infra_node_node_filesystem_free_bytes_2025-06-27.parquet: baseline_mean=9171308953.60, incident_mean=9187790652.95, incident_max=9200734208.00, score=0.00, samples=21
- node_network_transmit_bytes_total [aiops-k8s-08] from infra_node_node_network_transmit_bytes_total_2025-06-27.parquet: baseline_mean=5462.38, incident_mean=5461.33, incident_max=5465.87, score=0.00, samples=21

## Log Signals

- frontend-2 @ aiops-k8s-08: count=2111, window=2025-06-27T08:10:31.517Z -> 2025-06-27T08:31:30.890Z, pattern=json message=request complete severity=debug http.resp.status=<n>
- frontend-2 @ aiops-k8s-08: count=2111, window=2025-06-27T08:10:31.398Z -> 2025-06-27T08:31:30.801Z, pattern=json message=request started severity=debug
- frontend-2 @ aiops-k8s-08: count=1006, window=2025-06-27T08:10:35.379Z -> 2025-06-27T08:31:30.801Z, pattern=json message=serving product page severity=debug
- adservice-2 @ aiops-k8s-08: count=773, window=2025-06-27T08:10:34.968Z -> 2025-06-27T08:31:29.284Z, pattern={"logEvent":"received ad request (context_words=[])","logging.googleapis.com/trace":"${ctx:traceId}","logging.googleapis.com/spanId":"${ctx:spanId}","logging.googleapis.com/traceSampled":"${ctx:traceSampled}","time":"<n>
- adservice-2 @ aiops-k8s-08: count=694, window=2025-06-27T08:10:32.129Z -> 2025-06-27T08:31:30.464Z, pattern={"logEvent":"received ad request (context_words=[[\"gardening\"]])","logging.googleapis.com/trace":"${ctx:traceId}","logging.googleapis.com/spanId":"${ctx:spanId}","logging.googleapis.com/traceSampled":"${ctx:traceSample
- adservice-2 @ aiops-k8s-08: count=683, window=2025-06-27T08:10:34.545Z -> 2025-06-27T08:31:26.386Z, pattern={"logEvent":"received ad request (context_words=[[\"cookware\"]])","logging.googleapis.com/trace":"${ctx:traceId}","logging.googleapis.com/spanId":"${ctx:spanId}","logging.googleapis.com/traceSampled":"${ctx:traceSampled

## Trace Signals

- no trace signal extracted

## Retrieval Keywords

aiops-k8s-08 node_disk_read_bytes_total node_memory_MemAvailable_bytes node_memory_usage_rate node_disk_written_bytes_total node_filesystem_free_bytes
