# Telemetry Evidence Case

- case_id: b4feec3f-413
- time_window_utc: 2025-06-20T22:10:09Z -> 2025-06-20T22:34:09Z
- instance_type: service
- service: checkoutservice
- instance: checkoutservice

## Anomaly Description

Determine the root cause of the system fault during 2025-06-20T22:10:09Z to 2025-06-20T22:34:09Z.

## Metric Signals

- server_error_ratio [hipstershop] from pod_ns_hipstershop_2025-06-21.parquet: baseline_mean=0.00, incident_mean=0.11, incident_max=0.17, score=32.62, samples=24
- server_error [hipstershop] from pod_ns_hipstershop_2025-06-21.parquet: baseline_mean=0.33, incident_mean=10.33, incident_max=16.00, score=30.00, samples=24
- pod_cpu_usage [checkoutservice-0,checkoutservice-2,checkoutservice-1] from infra_pod_pod_cpu_usage_2025-06-21.parquet: baseline_mean=0.00, incident_mean=0.00, incident_max=0.00, score=1.00, samples=72
- pod_network_transmit_bytes [checkoutservice-0,checkoutservice-2,checkoutservice-1] from infra_pod_pod_network_transmit_bytes_2025-06-21.parquet: baseline_mean=425.20, incident_mean=0.16, incident_max=11.51, score=1.00, samples=71
- pod_network_receive_bytes [checkoutservice-0,checkoutservice-2,checkoutservice-1] from infra_pod_pod_network_receive_bytes_2025-06-21.parquet: baseline_mean=220.33, incident_mean=0.16, incident_max=11.51, score=1.00, samples=71
- pod_network_transmit_packets [checkoutservice-0,checkoutservice-2,checkoutservice-1] from infra_pod_pod_network_transmit_packets_2025-06-21.parquet: baseline_mean=2.45, incident_mean=0.00, incident_max=0.21, score=1.00, samples=71
- pod_network_receive_packets [checkoutservice-0,checkoutservice-2,checkoutservice-1] from infra_pod_pod_network_receive_packets_2025-06-21.parquet: baseline_mean=2.06, incident_mean=0.00, incident_max=0.21, score=1.00, samples=71
- pod_memory_working_set_bytes [checkoutservice-0,checkoutservice-2,checkoutservice-1] from infra_pod_pod_memory_working_set_bytes_2025-06-21.parquet: baseline_mean=100612.42, incident_mean=33437.72, incident_max=701644.20, score=0.67, samples=72

## Log Signals

- no log signal extracted

## Trace Signals

- frontend | hipstershop.CheckoutService/PlaceOrder: peer=hipstershop.CheckoutService, count=124, errors=124, avg_ms=0.28, p95_ms=0.63

## Retrieval Keywords

checkoutservice server_error_ratio server_error pod_cpu_usage pod_network_transmit_bytes pod_network_receive_bytes frontend hipstershop.CheckoutService/PlaceOrder
